
<footer id="footer" class="footer dark-background">

<div class="container footer-top">
  <div class="row gy-4">
    <div class="col-lg-4 col-md-6 footer-about">
      <a href="index.html" class="logo d-flex align-items-center">
        <span class="sitename">Doel Survey & Inspection LTD</span>
      </a>
      <div class="footer-contact pt-3">
        <p>Hasina Tower(5th floor),Agrabad Chattogram</p>
        <p>Shahnawaz Bhaban(4th Floor),9/c,Motijheel,Dhaka</p><br>
        <p class="mt-3"><strong>Phone:</strong> <span>01733559793,01712142835</span></p>
        <p><strong>Email:</strong> <span>doel.surveyinspections@gmail.com</span></p>
      </div>
      <div class="social-links d-flex mt-4">
        <a href=""><i class="bi bi-twitter-x"></i></a>
        <a href=""><i class="bi bi-facebook"></i></a>
        <a href=""><i class="bi bi-instagram"></i></a>
        <a href=""><i class="bi bi-linkedin"></i></a>
      </div>
    </div>

    <div class="col-lg-2 col-md-3 footer-links">
      <h4>Useful Links</h4>
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Our networking</a></li>
        <li><a href="#">Services</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
    </div>

    <div class="col-lg-2 col-md-3 footer-links ms-3">
      <h4>Our Main Services</h4>
      <ul>
        <li><a href="">Property Valuation</a></li>
        <li><a href="">Risk Management</a></li>
        <li><a href="">Loss Adjustment & Assessment</a></li>
        <li><a href="">Quality control</a></li>
        <li><a href="">Loss Prevention</a></li>
       
      </ul>
    </div>

    <div class="col-lg-2 col-md-3 footer-links ms-3">
      <h4>Other Services</h4>
      <ul>
        <li><a href="">After Loading Inspecttion</a></li>
        <li><a href="">Consultancy Third Party Inspection</a></li>
        <li><a href="">Consumer Product Inspection</a></li>
      </ul>
    </div>

    

  </div>
</div>



</footer>

<!-- Scroll Top -->
<a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<!-- Preloader -->
<div id="preloader"></div>

<!-- Vendor JS Files -->
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>
<script src="assets/vendor/aos/aos.js"></script>
<script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
<script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>

<!-- Main JS File -->
<script src="assets/js/main.js"></script>

</body>

</html>